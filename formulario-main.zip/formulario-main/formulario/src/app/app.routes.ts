import { Routes } from '@angular/router';
import { FormularioComponent } from './components/formulario/formulario';

export const routes: Routes = [
  { path: '', component: FormularioComponent }
];